# 【急速入门】 Cmake - 从结构化项目到动态库

## 1. 下载Cmake

这里就不赘述了，具体方法可以:

Deepseek/GPT/Kimi/豆包/Poe先生，帮帮我！

## 2. 应用场景介绍

复杂来说，Cmake(Cross-platform Make)是一个跨平台的构建系统生成器，用于管理和简化软件项目的构建过程。它的主要作用是生成构建文件（如 Makefile 或项目文件），这些文件可以被编译器和构建工具（如 make、Visual Studio 或其他 IDE）用来编译、链接和生成可执行文件或库。

简单来说(在这种入门场景下)，针对C/C++的项目，涉及到多个文件与复杂结构时，需要编写makefile来控制编译，但有点麻烦。博主博主，你的gcc和makefile确实很强，但还是太吃操作了，有没有————而Cmake则是一个方便的makefile生成工具。(Cmake -> makefile -> g++/gcc)

## 3. Cmake使用：自简向难方法

### 3.1. 一个源文件

1. 目录结构

   ``` sh
    .
    ├── CMakeLists.txt
    └── main.cpp
   ```

2. CMakeLists.txt(事实上，大小写并不重要)

   ``` cmake
    # 需要cmake的最低版本，可以用命令cmake --version查看自己的
    cmake_minimum_required(VERSION 3.10)

    # 声明工程名称
    project(project1)

    # 声明生成的目标文件及依赖的源代码
    add_executable(dio main.cpp)
   ```

3. 操作与结果(从项目根目录出发)

    对于一个cpp文件来说，最经典的当然是直接gcc main.cpp -o dio，但是如果是用cmake的话，以下两步之内也能搞定

    ``` sh
    cmake .
    make
    ```

    然后你的目录会变成

    ``` sh
    .
    ├── CMakeCache.txt
    ├── CMakeFiles
    ├── CMakeLists.txt
    ├── Makefile
    ├── cmake_install.cmake
    ├── dio
    └── main.cpp
    ```

    另外，你会发现之后如果改动了main.cpp需要重新编译的话，直接make即可，这是因为Cmake生成makefile的使命已经完成了，它和源代码或编译过程并不直接相关

### 3.2. 源文件+头文件

1. 目录结构

   事实上，更常见的目录结构应该是这样的

    ``` sh
    .
    ├── CMakeLists.txt
    ├── include
    │   ├── func1.hpp
    │   └── func2.hpp
    └── src
        ├── func1.cpp
        ├── func2.cpp
        └── main.cpp
    ```

2. CMakeLists.txt

    ``` cmake
    cmake_minimum_required(VERSION 3.10)

    project(project2)

    # 设置输出的可执行文件的位置，也就是项目根目录下的bin文件夹内
    set(EXECUTABLE_OUTPUT_PATH ${PROJECT_SOURCE_DIR}/bin)

    # 指定头文件路径(这里include就是根目录下的文件夹名)
    include_directories(include)

    # 将源码的.cpp文件保存在SRC_LIST变量中(通过一个变量，可以避免手动一个一个加)
    aux_source_directory(src SRC_LIST)

    # 自己定义的变量都需要${para}来使用
    add_executable(battle ${SRC_LIST})
    ```

3. 操作与结果

    一般来说，会创建一个build文件夹来存放中间生成的那些奇奇怪怪的cmake相关文件，而bin文件夹来存放编译得到的可执行文件

    ```sh
    mkdir build
    cd build
    cmake ..
    make
    ```

    或者

    ```sh
    cmake -B build
    cd build
    make
    ```

    之后就可以去bin文件夹中找到可执行文件啦

    ```sh
    .
    ├── CMakeLists.txt
    ├── bin
    │   └── battle
    ├── build
    │   ├── CMakeCache.txt
    │   ├── CMakeFiles
    │   ├── Makefile
    │   └── cmake_install.cmake
    ├── include
    │   ├── func1.hpp
    │   └── func2.hpp
    └── src
        ├── func1.cpp
        ├── func2.cpp
        └── main.cpp
    ```

    另，make生成出的相关文件可以通过make clean清除

### 3.3. 动态库

1. 动态库简介
2. 目录结构

    ```sh
    .
    ├── CMakeLists.txt
    ├── include
    │   ├── math.hpp
    │   └── sharedlib.hpp
    ├── lib
    │   └── libmysharedlib.so
    └── src
        ├── main.cpp
        ├── math.cpp
        └── sharedlib.cpp
    ```

    这里libmysharedlib.so是通过sharedlib.cpp已经生成的动态库，而math.cpp还没有生成对应的动态库

3. CMakeLists.txt

    ``` cmake
    cmake_minimum_required(VERSION 3.10)
    project(project3)
    include_directories(include)
    add_executable(joseph src/main.cpp)
    # 设置可执行文件输出路径
    set_target_properties(joseph PROPERTIES RUNTIME_OUTPUT_DIRECTORY ${PROJECT_SOURCE_DIR}/bin)

    # 创建共享库
    set(LIB_SRC
        ./src/math.cpp
        )

    add_library(mathlib SHARED ${LIB_SRC})

    # 直接找创建的/从别处获得的动态库(.so)
    # NAMES中省去前缀lib和后缀.so
    find_library(MYSHARED_LIB
                NAMES mysharedlib
                PATHS ${PROJECT_SOURCE_DIR}/lib)

    set(LIBS
        ${MYSHARED_LIB}
        mathlib
        )

    # 连接动态库
    target_link_libraries(joseph ${LIBS})

    # 设置动态库输出路径
    set(LIBRARY_OUTPUT_PATH ${PROJECT_SOURCE_DIR}/lib)
    ```

4. 操作

   这里的操作和2中基本无异，不过在运行之后会得到math.cpp对应的动态库/lib/libmathlib.so

至此，你已经学会基本的Cmake使用啦，快点尝试搭建一个自己的项目并使用Cmake辅助开发吧:smile:

## 4. 致谢

博主也是在B站看视频学的，如果大家觉得不够详细的话也可以去看看[原作](https://www.bilibili.com/video/BV1nw411C71Z?spm_id_from=333.788.videopod.sections&vd_source=a74c895f641474b4a0acb8b17d40b441)
