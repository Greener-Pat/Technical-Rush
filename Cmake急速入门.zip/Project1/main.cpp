#include <iostream>

int main() {
    std::cout << "THE WORLD!\n";
    return 0;
}