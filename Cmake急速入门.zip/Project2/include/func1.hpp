#ifndef _FUNC1_H
#define _FUNC1_H

void Jotaro();

#endif