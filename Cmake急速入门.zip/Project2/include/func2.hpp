#ifndef _FUNC2_H
#define _FUNC2_H

void Dio();

#endif