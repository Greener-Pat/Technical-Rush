#include "func1.hpp"
#include "func2.hpp"

int main() {
    Dio();
    Jotaro();
    return 0;
}