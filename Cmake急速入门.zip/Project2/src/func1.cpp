#include "func1.hpp"
#include <iostream>

void Jotaro() {
    std::cout << "oulaoulaoulaoulaoula!\n";
}