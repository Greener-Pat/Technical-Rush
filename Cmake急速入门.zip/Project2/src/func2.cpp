#include "func2.hpp"
#include <iostream>

void Dio() {
    std::cout << "mudamudamudamuda!\n";
}