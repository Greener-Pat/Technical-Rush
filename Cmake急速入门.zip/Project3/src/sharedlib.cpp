#include <iostream>

void Joseph() {
    std::cout << "Oh, my God!\n";
}