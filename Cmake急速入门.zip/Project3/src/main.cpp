#include "sharedlib.hpp"
#include "math.hpp"
#include <iostream>

int main() {
    Joseph();
    std::cout << "1 plus 1 equal to " << plus(1, 1) << "\n";
    return 0;
}