#ifndef _MATH_H
#define _MATH_H

int plus(int a, int b);

#endif