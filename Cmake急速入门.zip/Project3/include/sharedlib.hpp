#ifndef _SHAREDLIB_H
#define _SHAREDLIB_H

void Joseph();

#endif